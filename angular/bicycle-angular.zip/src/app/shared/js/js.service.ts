import { Injectable } from '@angular/core';
declare var $:any;

@Injectable({
  providedIn: 'root'
})
export class JsService {

  constructor() { }
  
  callJsClass(){
    // $.getScript("../../../assets/assets/js/owl-carousel/owl.carousel.min.js");
    // $.getScript("../../../assets/assets/js/owl-carousel/app.js");
    // $.getScript("../../../assets/assets/js/owl-carousel/highlight.js");
    // $.getScript("../../../assets/assets/js/custom.js");
    // $.getScript("../../../assets/assets/js/jquery.fancybox.min.js");
    // $.getScript("../../../assets/assets/js/jquery.min.js");
  }
}
